// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from motor_driver:msg/MotorAlarm.idl
// generated code does not contain a copyright notice

#ifndef MOTOR_DRIVER__MSG__DETAIL__MOTOR_ALARM__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define MOTOR_DRIVER__MSG__DETAIL__MOTOR_ALARM__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "motor_driver/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_motor_driver
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, motor_driver, msg, MotorAlarm)();

#ifdef __cplusplus
}
#endif

#endif  // MOTOR_DRIVER__MSG__DETAIL__MOTOR_ALARM__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
